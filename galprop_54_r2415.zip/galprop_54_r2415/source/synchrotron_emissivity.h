double synchrotron_emissivity(double gamma, double nu,  double Bperp, double Brand,
                              double &synch_emissivity_regular,       double &synch_emissivity_parallel, double &synch_emissivity_perpendicular,
                              double &synch_emissivity_random,
                              int debug=0 );
